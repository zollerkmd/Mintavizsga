import router from "src/router";

export const install = (app: any) => {
  app.use(router);
};
